Connection String to my server: server=localhost;database=it607labs;Uid=student;pwd=secret

Customer excel file needs to be in the same directory as the excecutable.

the output excel file will be called "output.xlsx"

!!! I have added the database file in the zip file. need to setup a server on localhost!!!

Im pretty sure the project called "Lab11TransactionsExcelSQL" is the main program. if it does not work, try the other one aswell :P